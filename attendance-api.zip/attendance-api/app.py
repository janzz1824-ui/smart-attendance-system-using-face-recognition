from flask import Flask, request, jsonify
import sqlite3
from datetime import datetime
import os

app = Flask(__name__)
DB = "/data/attendance.db"
os.makedirs("/data", exist_ok=True)

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS attendance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                student_name TEXT NOT NULL,
                subject TEXT DEFAULT 'General',
                timestamp TEXT NOT NULL,
                status TEXT DEFAULT 'PRESENT'
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS students (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE NOT NULL,
                registered_at TEXT NOT NULL
            )
        """)
        conn.commit()

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

@app.route("/add_student", methods=["POST"])
def add_student():
    name = request.json.get("name")
    if not name:
        return jsonify({"error": "name required"}), 400
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_db() as conn:
        try:
            conn.execute(
                "INSERT OR IGNORE INTO students (name, registered_at) VALUES (?,?)",
                (name, timestamp)
            )
            conn.commit()
        except:
            pass
    return jsonify({"message": f"{name} added"})

@app.route("/mark", methods=["POST"])
def mark():
    data = request.json
    name = data.get("name")
    subject = data.get("subject", "General")
    if not name or name == "Unknown":
        return jsonify({"error": "Cannot mark Unknown"}), 400
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with get_db() as conn:
        conn.execute(
            "INSERT INTO attendance (student_name, subject, timestamp) VALUES (?,?,?)",
            (name, subject, timestamp)
        )
        conn.commit()
    return jsonify({"message": f"Attendance marked for {name}", "timestamp": timestamp})

@app.route("/records", methods=["GET"])
def records():
    subject = request.args.get("subject")
    date = request.args.get("date")
    query = "SELECT * FROM attendance WHERE 1=1"
    params = []
    if subject:
        query += " AND subject=?"
        params.append(subject)
    if date:
        query += " AND timestamp LIKE ?"
        params.append(f"{date}%")
    query += " ORDER BY timestamp DESC"
    with get_db() as conn:
        rows = conn.execute(query, params).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route("/summary", methods=["GET"])
def summary():
    with get_db() as conn:
        # Get all registered students
        students = conn.execute(
            "SELECT name FROM students ORDER BY name"
        ).fetchall()
        # Get attendance counts
        att = conn.execute("""
            SELECT student_name, COUNT(*) as count, MAX(timestamp) as last_seen
            FROM attendance GROUP BY student_name
        """).fetchall()
    att_dict = {r["student_name"]: dict(r) for r in att}
    result = []
    for s in students:
        name = s["name"]
        if name in att_dict:
            result.append(att_dict[name])
        else:
            result.append({
                "student_name": name,
                "count": 0,
                "last_seen": "Never"
            })
    return jsonify(result)

@app.route("/delete_student", methods=["POST"])
def delete_student():
    name = request.json.get("name")
    if not name:
        return jsonify({"error": "name required"}), 400
    with get_db() as conn:
        conn.execute("DELETE FROM attendance WHERE student_name=?", (name,))
        conn.execute("DELETE FROM students WHERE name=?", (name,))
        conn.commit()
    return jsonify({"message": f"All records for {name} deleted"})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5002)