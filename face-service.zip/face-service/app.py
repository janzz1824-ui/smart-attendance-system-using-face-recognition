from flask import Flask, request, jsonify
import face_recognition
import numpy as np
import os
import pickle

app = Flask(__name__)
KNOWN_FACES_DIR = "/app/known_faces"
ENCODINGS_FILE = "/app/known_faces/encodings.pkl"

os.makedirs(KNOWN_FACES_DIR, exist_ok=True)

def load_encodings():
    if os.path.exists(ENCODINGS_FILE):
        with open(ENCODINGS_FILE, "rb") as f:
            data = pickle.load(f)
            if isinstance(data, tuple) and len(data) == 2:
                return data
    return [], []

def save_encodings(names, encodings):
    with open(ENCODINGS_FILE, "wb") as f:
        pickle.dump((names, encodings), f)

@app.route("/health")
def health():
    return jsonify({"status": "ok"})

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name")
    files = request.files.getlist("photo")
    if not name:
        return jsonify({"error": "name required"}), 400
    if not files:
        return jsonify({"error": "at least one photo required"}), 400

    names, encodings = load_encodings()
    added = 0

    for file in files:
        try:
            img = face_recognition.load_image_file(file)
            encs = face_recognition.face_encodings(img)
            if encs:
                names.append(name)
                encodings.append(encs[0])
                added += 1
        except Exception as e:
            continue

    if added == 0:
        return jsonify({"error": "No face detected in any photo"}), 400

    save_encodings(names, encodings)
    return jsonify({
        "message": f"{name} registered successfully with {added} photo(s)"
    })

@app.route("/predict", methods=["POST"])
def predict():
    file = request.files.get("photo")
    if not file:
        return jsonify({"error": "photo required"}), 400

    try:
        img = face_recognition.load_image_file(file)
        unknown_encs = face_recognition.face_encodings(img)
    except Exception as e:
        return jsonify({"name": "Unknown", "confidence": 0})

    if not unknown_encs:
        return jsonify({"name": "Unknown", "confidence": 0})

    names, encodings = load_encodings()
    if not encodings:
        return jsonify({"name": "Unknown", "confidence": 0})

    distances = face_recognition.face_distance(encodings, unknown_encs[0])
    best_idx = int(np.argmin(distances))
    confidence = round((1 - float(distances[best_idx])) * 100, 2)

    if distances[best_idx] < 0.45:
        return jsonify({
            "name": names[best_idx],
            "confidence": confidence
        })
    return jsonify({"name": "Unknown", "confidence": confidence})

@app.route("/students", methods=["GET"])
def students():
    names, _ = load_encodings()
    unique = list(set(names))
    return jsonify({"students": unique, "count": len(unique)})

@app.route("/delete", methods=["POST"])
def delete():
    name = request.json.get("name")
    if not name:
        return jsonify({"error": "name required"}), 400
    names, encodings = load_encodings()
    new_names, new_encodings = [], []
    for n, e in zip(names, encodings):
        if n != name:
            new_names.append(n)
            new_encodings.append(e)
    save_encodings(new_names, new_encodings)
    return jsonify({"message": f"{name} deleted"})

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)