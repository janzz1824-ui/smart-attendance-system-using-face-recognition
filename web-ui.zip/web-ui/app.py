from flask import Flask, request, render_template
import requests
import os
from datetime import datetime

app = Flask(__name__)
FACE_SVC = "http://face-service:5001"
ATT_SVC  = "http://attendance-api:5002"

def get_summary():
    try:
        return requests.get(f"{ATT_SVC}/summary").json()
    except:
        return []

def get_all_records():
    try:
        return requests.get(f"{ATT_SVC}/records").json()
    except:
        return []

def get_today_records():
    try:
        today = datetime.now().strftime("%Y-%m-%d")
        return requests.get(f"{ATT_SVC}/records?date={today}").json()
    except:
        return []

def render(message=None):
    records = get_summary()
    all_records = get_all_records()
    today_records = get_today_records()
    today_present = len(set(r["student_name"] for r in today_records))
    today_absent = max(0, len(records) - today_present)
    return render_template("index.html",
        records=records,
        all_records=all_records,
        today_records=today_records,
        today_present=today_present,
        today_absent=today_absent,
        total_records=len(all_records),
        message=message)

@app.route("/")
def index():
    return render()

@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name")
    photos = request.files.getlist("photo")
    try:
        files = [("photo", (p.filename, p.read(), p.mimetype)) for p in photos]
        resp = requests.post(f"{FACE_SVC}/register", data={"name": name}, files=files)
        msg = resp.json().get("message") or resp.json().get("error")
        if "successfully" in str(msg):
            requests.post(f"{ATT_SVC}/add_student", json={"name": name})
            msg = f"✅ {msg}"
        else:
            msg = f"❌ {msg}"
    except Exception as e:
        msg = f"❌ Error: {str(e)}"
    return render(msg)

@app.route("/mark", methods=["POST"])
def mark():
    subject = request.form.get("subject", "CC")
    photo = request.files.get("photo")
    photo_bytes = photo.read()
    try:
        pred = requests.post(f"{FACE_SVC}/predict",
            files={"photo": ("photo.jpg", photo_bytes, "image/jpeg")}).json()
        name = pred.get("name", "Unknown")
        confidence = pred.get("confidence", 0)
        if name != "Unknown":
            requests.post(f"{ATT_SVC}/mark",
                json={"name": name, "subject": subject})
            msg = f"✅ {name} marked PRESENT for {subject}! Confidence: {confidence}%"
        else:
            msg = f"❌ Face not recognised. Please register first. Confidence: {confidence}%"
    except Exception as e:
        msg = f"❌ Error: {str(e)}"
    return render(msg)

@app.route("/delete_student", methods=["POST"])
def delete_student():
    name = request.form.get("name")
    try:
        requests.post(f"{FACE_SVC}/delete", json={"name": name})
        requests.post(f"{ATT_SVC}/delete_student", json={"name": name})
        msg = f"✅ {name} deleted successfully!"
    except Exception as e:
        msg = f"❌ Error deleting {name}: {str(e)}"
    return render(msg)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5003)